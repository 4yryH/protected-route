import React from "react";

export const Profile = () => {
  return (
    <>
      <h1>Страница профиля пользователя</h1>
    </>
  );
};
