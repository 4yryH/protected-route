import React from "react";

const NotFoundPage = () => {
  return (
    <>
      <h1>404</h1>
      <p>Упс... Страница не найдена</p>
    </>
  );
};

export default NotFoundPage;
