import React from "react";

export const Home = () => {
  return (
    <>
      <h1>Добро пожаловать!</h1>
    </>
  );
};
