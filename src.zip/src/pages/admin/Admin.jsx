import React from "react";

export const Admin = () => {
  return (
    <>
      <h1>Страница администратора</h1>
    </>
  );
};
