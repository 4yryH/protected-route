import React from "react";
import "./Login.css";

export const Login = () => {
  return (
    <>
      <h1>Авторизуйтесь</h1>
      <form>
        <div className="form-wrapper">
          <label htmlFor="login">Введите логин</label>
          <input type="text" name="login" id="login" placeholder="Логин" />
          <label htmlFor="password">Введите пароль</label>
          <input
            type="password"
            name="password"
            id="password"
            placeholder="Пароль"
          />
        </div>
        <button>Войти</button>
      </form>
    </>
  );
};
