import { useState } from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Layout } from "./Layout.jsx";
import NotFoundPage from "./pages/404/404.jsx";
import { Home } from "./pages/home/Home.jsx";
import ProtectedRoute from "./components/protected-route/ProtectedRoute.jsx";
import { Login } from "./pages/login/Login.jsx";
import { Profile } from "./pages/profile/Profile.jsx";
import { Admin } from "./pages/admin/Admin.jsx";
import "./App.css";

function App() {
  const [isAuth, setIsAuth] = useState(false);
  const router = createBrowserRouter([
    {
      path: "/",
      element: <Layout />,
      children: [
        {
          index: true,
          element: <Home />,
        },
        {
          path: "profile",
          element: (
            <ProtectedRoute isAuth={isAuth}>
              <Profile onLogout={() => setIsAuth(false)} />
            </ProtectedRoute>
          ),
        },
        {
          path: "admin",
          element: (
            <ProtectedRoute isAuth={isAuth}>
              <Admin onLogout={() => setIsAuth(false)} />
            </ProtectedRoute>
          ),
        },
        {
          path: "login",
          element: <Login setIsAuth={setIsAuth} />,
        },
        {
          path: "*",
          element: <NotFoundPage />,
        },
      ],
    },
  ]);

  return (
    <>
      return <RouterProvider router={router} />
    </>
  );
}

export default App;
