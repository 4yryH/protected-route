import React from "react";
import { NavLink } from "react-router-dom";
import "./Navigation.css";

export const Navigation = () => {
  return (
    <>
      <nav>
        <NavLink
          to="/"
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Домашняя страница
        </NavLink>

        <NavLink
          to="/profile"
          end
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Профиль
        </NavLink>

        <NavLink
          to="/admin"
          end
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Админ
        </NavLink>

        <NavLink
          to="/login"
          end
          className={({ isActive }) =>
            isActive ? "nav-link active" : "nav-link"
          }
        >
          Логин
        </NavLink>
      </nav>
    </>
  );
};
